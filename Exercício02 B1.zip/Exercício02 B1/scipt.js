let inputvalor1 = document.querySelector("#inputvalor1");
let inputvalor2 = document.querySelector("#inputvalor2");
let inputvalor3 = document.querySelector("#inputvalor3");
let inputvalor4 = document.querySelector("#inputvalor4");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function Calcular(){

    let valor1 = Number(inputvalor1.value);
    let valor2 = Number(inputvalor2.value);
    let valor3 = Number(inputvalor3.value);
    let valor4 = Number(inputvalor4.value);

}
btCalcular.onclick = function(){
    CalcularAumento();
}
    


