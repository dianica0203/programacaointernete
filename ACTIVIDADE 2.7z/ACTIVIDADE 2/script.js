let inputvalo1 = document.querySelector("#inputvalor1");
let inputvalor2 = document.querySelector("#inputvalor2");
let  btpago = document.querySelector("#btpago");
let h3Troco = document.querySelector("#h3Troco");

function trocovalor(){

    let valor1 = Number(inputvalor1.value);
    let valor2 = Number(inputvalor2.value);
    
    h3Troco.textContent =(valor1-valor2);
}
btpago.onclick = function(){
    trocovalor();
}